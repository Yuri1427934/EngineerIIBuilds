#pragma once
#include <Engine/GameObject/cGameObject.h>
namespace yuriSystem
{
	namespace Tilemap
	{
		//You can modify this class to whatever you want the tiles have
		class cTileData
		{
		public:
			sCoordinate coordinate{ 0,0 };
			eae6320::Physics::sRigidBodyState m_rigidBody;
			cTileData() = default;
		};
	}
}