#pragma once
#include <Engine/Results/cResult.h>
#include "sCoordinate.h"
#include <Engine/Math/sVector.h>
#include <Engine/Results/Results.h>
#include <Engine/Graphics/Graphics.h>
#include <Engine/GameObject/cGameObject.h>
#include "cTileData.h"

namespace yuriSystem
{
	namespace Tilemap
	{
		
		class cTillemap
		{
		public:
			//Load the tilemap
			static eae6320::cResult Load(unsigned int i_size_x, unsigned int i_size_y, float i_tileSize_x, float i_tileSize_y,float i_objYOffset, cTillemap*& o_tilemap);
			eae6320::Physics::sRigidBodyState m_rigidBody;	//RigidBody of this tilemap(consider as the center point)
			//Get the position of the tile + Y offset you set
			eae6320::Math::sVector GetWorldPos(sCoordinate i_coord);
			eae6320::Math::sVector GetWorldPos(unsigned int i_x, unsigned int i_y);
			//Get the number of the tiles
			int getTileCount() { return size_x * size_y; };
			//For simulate purpose
			void updateTile(const float i_elapsedSecondCount_sinceLastUpdate);
			cTillemap() = default;
			cTileData* getTileData(sCoordinate i_coord);
			cTileData* getTileData(unsigned int i_x, unsigned int i_y);
			eae6320::cResult CleanUp();
		private:
			eae6320::cResult Initialize(unsigned int i_size_x, unsigned int i_size_y, float i_tileSize_x, float i_tileSize_y, float i_objYOffset);
			eae6320::Math::sVector getTilePos(sCoordinate i_coord);
			unsigned int size_x = 0;//The size of the tilemap(how many tiles on tilemap of X axis)
			unsigned int size_y = 0;//The size of the tilemap(how many tiles on tilemap of Z axis)
			float tileSize_x = 0;//The x size of the tile
			float tileSize_y = 0;//The y size of the tile
			float objYOffset = 0;//The offset you want the object put on the tile
			cTileData** tiles = nullptr;//Tile datas of the tilemap
		};


	}
}