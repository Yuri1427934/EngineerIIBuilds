#pragma once

namespace yuriSystem
{
	namespace Tilemap
	{
		struct sCoordinate
		{
			sCoordinate(unsigned int i_x, unsigned int i_y) :x(i_x), y(i_y) {};
			unsigned int x = 0, y = 0;
		};
	}
}