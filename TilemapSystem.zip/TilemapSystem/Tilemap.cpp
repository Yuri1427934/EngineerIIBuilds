#include "Tilemap.h"

#include <Engine/Logging/Logging.h>
#include <Engine/Asserts/Asserts.h>
eae6320::cResult yuriSystem::Tilemap::cTillemap::Load(unsigned int i_size_x, unsigned int i_size_y, float i_tileSize_x, float i_tileSize_y, float i_objYOffset, cTillemap*& o_tilemap)
{
	auto result = eae6320::Results::Success;
	cTillemap* newtilemap = new cTillemap();
	if (!(result=newtilemap->Initialize(i_size_x, i_size_y, i_tileSize_x, i_tileSize_y, i_objYOffset)))
	{
		return result;
	}
	o_tilemap = newtilemap;
	return result;

};
eae6320::cResult yuriSystem::Tilemap::cTillemap::Initialize(unsigned int i_size_x, unsigned int i_size_y, float i_tileSize_x, float i_tileSize_y, float i_objYOffset)
{
	auto result = eae6320::Results::Success;
	size_x = i_size_x;
	size_y = i_size_y;
	tileSize_x = i_tileSize_x;
	tileSize_y = i_tileSize_y;
	objYOffset = i_objYOffset;
	tiles = new yuriSystem::Tilemap::cTileData * [size_y];
	for (unsigned int y = 0; y < size_y; y++)
	{
		tiles[y] = new yuriSystem::Tilemap::cTileData[size_x];
		eae6320::Math::sVector newPos = eae6320::Math::sVector(m_rigidBody.position.x - ((tileSize_x / 2) * (size_x - 1)), m_rigidBody.position.y, m_rigidBody.position.z - ((tileSize_y / 2) * (size_y - 1)));
		for (unsigned int x = 0; x < size_x; x++)
		{
			tiles[y][x].coordinate = sCoordinate(x, y);
			tiles[y][x].m_rigidBody.position = getTilePos(sCoordinate(x, y));
		}
	}
	return result;
}

eae6320::cResult yuriSystem::Tilemap::cTillemap::CleanUp()
{
	for (unsigned int i = 0; i < size_y; i++)
	{
		delete[] tiles[i];
	}
	delete[] tiles;
	return eae6320::Results::Success;
};
eae6320::Math::sVector yuriSystem::Tilemap::cTillemap::GetWorldPos(yuriSystem::Tilemap::sCoordinate i_coord)
{
	return GetWorldPos(i_coord.x, i_coord.y);
};

eae6320::Math::sVector yuriSystem::Tilemap::cTillemap::GetWorldPos(unsigned int i_x, unsigned int i_y)
{
	unsigned int _x = 0;
	unsigned int _y = 0;
	if (i_x >= size_x)_x = size_x - 1;
	if (i_x > 0)_x = i_x;
	if (i_y >= size_y)_y = size_y - 1;
	if (i_y > 0)_y = i_y;
	return getTilePos(sCoordinate(_x, _y)) + eae6320::Math::sVector(0.0f, objYOffset, 0.0f);
};

eae6320::Math::sVector yuriSystem::Tilemap::cTillemap::getTilePos(yuriSystem::Tilemap::sCoordinate i_coord)
{
	return eae6320::Math::sVector(m_rigidBody.position.x - ((tileSize_x / 2) * (size_x - 1)) + static_cast<float>(i_coord.x * tileSize_x), m_rigidBody.position.y, m_rigidBody.position.z - ((tileSize_y / 2) * (size_y - 1)) + static_cast<float>(i_coord.y * tileSize_y));
};

void yuriSystem::Tilemap::cTillemap::updateTile(const float i_elapsedSecondCount_sinceLastUpdate)
{
	m_rigidBody.Update(i_elapsedSecondCount_sinceLastUpdate);
	for (unsigned int y = 0; y < size_y; y++)
	{
		for (unsigned int x = 0; x < size_x; x++)
		{
			tiles[y][x].m_rigidBody.position = getTilePos(sCoordinate(x, y));
			tiles[y][x].m_rigidBody.Update(i_elapsedSecondCount_sinceLastUpdate);
		}
	}
}
yuriSystem::Tilemap::cTileData* yuriSystem::Tilemap::cTillemap::getTileData(sCoordinate i_coord)
{
	return getTileData(i_coord.x, i_coord.y);
};

yuriSystem::Tilemap::cTileData* yuriSystem::Tilemap::cTillemap::getTileData(unsigned int i_x, unsigned int i_y)
{
	unsigned int _x = 0;
	unsigned int _y = 0;
	if (i_x >= size_x)_x = size_x - 1;
	if (i_x > 0)_x = i_x;
	if (i_y >= size_y)_y = size_y - 1;
	if (i_y > 0)_y = i_y;
	return &tiles[_y][_x];
};


